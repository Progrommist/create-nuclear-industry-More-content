package com.createnuclearindustrys.Blocks.UraniumFuelRod;

import com.createnuclearindustrys.CNIBlocks;
import com.createnuclearindustrys.Utills.Interfaces.Emitted.FuelRodBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;


public class UraniumFuelRodEntity extends BlockEntity implements FuelRodBlockEntity {
    private int durability = 100000;
    public UraniumFuelRodEntity(BlockPos pos, BlockState blockState) {
        super(CNIBlocks.URANIUM_FUEL_ROD_ENTITY.get(), pos, blockState);
    }

    public int getDurability() {
        return this.durability;
    }
    public void decDurability() {
        this.durability--;
        if (this.durability <= 0) {
            level.setBlock(worldPosition, CNIBlocks.SPENT_FUEL_ROD.get().defaultBlockState(), 3);
        }
        this.setChanged();
    }
    public void setDurability(int Value) {
        this.durability = Value;
        this.setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("durability", this.durability);
    }

    @Override
    public void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.durability = tag.getInt("durability");
    }
}

package com.createnuclearindustrys.Utills.Interfaces.Emitted;

public interface FuelRodBlockEntity {
    int durability = 100000;
    public int getDurability();
    public void decDurability();
    public void setDurability(int Value);
}
